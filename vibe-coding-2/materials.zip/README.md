# Tutorial 2 Lab Materials

Build a local literature search tool using synthetic papers. Enter a query, browse ranked results, save papers, and export your reading list as a CSV file.

## Files

- `data/papers.json` contains 120 synthetic papers in English, with 10 papers in each of 12 topics.
- `reference/hipaper-search.png` is the reference screenshot for the frontend demo.

## Data fields

- `paper_id` uniquely identifies each paper across search results, saved lists, and CSV exports.
- `title` and `abstract` contain the paper title and abstract. You can combine them into a single text for embedding.
- `authors` is a list of author names. `year` is the publication year as an integer.
- `topic` is the topic label. `synthetic` is `true` for records created for this lab.

## Getting started

1. Extract the archive and open `Tutorial2_Lab` as your Code Agent workspace. Have the backend load `data/papers.json` from the project root.
2. Follow the slides to implement vector search with MiniLM. When building the frontend, attach the reference screenshot to your prompt.
3. Write your own tests. Put test code in `tests/` and test data and relevance judgments in `tests/fixtures/`. Record the commands you ran and the results in `tests/README.md`.