# Tutorial 1 materials

All measurements are synthetic classroom examples, not real benchmark claims.

## Files

- `training_curves.csv`: 659 observations across 3 datasets, 4 methods, 5 seeds and 11 epochs, with one missing measurement: Toy-C / Large / seed 4 / epoch 100.
- `benchmark_results.csv`: 60 runs containing test accuracy and inference latency in milliseconds. Accuracy in both CSVs is stored as a fraction in [0, 1].
- `requirements.txt`: plotting dependencies for Python 3.11. Install them into `.venv` before class.
- `AGENTS.example.md`: plotting-lab rules. Copy it to `AGENTS.md` in your exercise folder if supported by your coding client. Its no-new-test-files rule applies only to this plotting lab; Tutorial 2 requires tests.

## Exercises

Follow the current Tutorial 1 slides for prompts, installation commands and acceptance criteria. Generate your own plotting code and figure exports during the exercises.

For the CCFA-Skills exercise, reuse the in-slide Prompt B requirements (data and statistics, layout and acceptance) with `ccf-visual-composer`. If a slide mentions `figure_prompt_B.txt` or `ccfa_plot_prompt.txt`, use those slide prompts directly; no separate prompt files are needed.
