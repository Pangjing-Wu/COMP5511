"""Plot only observed values from the supplied simulated CSV."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

root = Path(__file__).parent
df = pd.read_csv(root / "toy_result.csv")
required = {"algorithm", "run", "step", "score"}
if not required.issubset(df.columns):
    raise ValueError(f"Required columns are {sorted(required)}")
if df[list(required)].isna().any().any():
    raise ValueError("Missing values require an explicit handling decision")
if df.duplicated(["algorithm", "run", "step"]).any():
    raise ValueError("Duplicate run and step observations")
print(df.info())
fig, ax = plt.subplots(figsize=(7.5, 4.5))
for (name, group), color in zip(df.groupby("algorithm"), ["#C00000", "#555555"]):
    stats = group.groupby("step")["score"].agg(["mean", "std", "count"])
    ax.plot(stats.index, stats["mean"], color=color, label=name)
    if (stats["count"] >= 2).all():
        ax.fill_between(stats.index, stats["mean"] - stats["std"], stats["mean"] + stats["std"], color=color, alpha=0.13)
ax.set(xlabel="Training step", ylabel="Simulated score")
ax.legend(frameon=False)
fig.tight_layout()
for extension in ["png", "svg"]:
    fig.savefig(root / f"figure.{extension}", dpi=160)
plt.close(fig)
print("Saved figure.png and figure.svg. Bands show one standard deviation across runs.")
