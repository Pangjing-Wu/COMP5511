# Plotting lab rules

## Runtime
Use Python 3.11 from .venv/bin/python.
Use pandas and matplotlib. Do not install extra packages.

## Data
Use training_curves.csv and benchmark_results.csv.
Source: COMP5511 synthetic classroom data.
Keep inputs unchanged. Do not download or invent values.

## Style and scope
Keep method colors and markers consistent across panels.
Export vector PDF/SVG and keep the runnable Python source.
Do not add test files or a testing framework for this lab.
Do not calculate file hashes or build a cache system.

## Verification
Run the script and inspect every panel.
Check schema, one raw-row mean/SD calculation, units and exports.
